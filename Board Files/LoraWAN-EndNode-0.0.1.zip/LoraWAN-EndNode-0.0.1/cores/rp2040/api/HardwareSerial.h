#pragma once
#include "../../../ArduinoCore-API/api/HardwareSerial.h"
