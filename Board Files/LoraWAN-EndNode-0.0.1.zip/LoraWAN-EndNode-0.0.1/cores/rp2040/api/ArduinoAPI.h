#pragma once
#include "../../../ArduinoCore-API/api/ArduinoAPI.h"
