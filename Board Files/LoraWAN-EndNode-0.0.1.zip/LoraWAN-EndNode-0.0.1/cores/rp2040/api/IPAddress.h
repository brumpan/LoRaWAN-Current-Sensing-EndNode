#pragma once
#include "../../../ArduinoCore-API/api/IPAddress.h"
